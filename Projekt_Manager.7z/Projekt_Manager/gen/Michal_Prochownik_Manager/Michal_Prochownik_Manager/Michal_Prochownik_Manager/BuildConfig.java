/** Automatically generated file. DO NOT MODIFY */
package Michal_Prochownik_Manager.Michal_Prochownik_Manager.Michal_Prochownik_Manager;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}